const http = require('http');
const fs = require("fs")
const fetch = require("node-fetch")

//create a server with the HTTP variable
const server = http.createServer(function (req, res) {
  //headers
  //res.writeHead(200, { 'Content-Type': 'text/plain' });
  // res.writeHead(200, { 'Content-Type': 'application/json' });
  fetch("https://jsonplaceholder.typicode.com/posts")
    .then(response => response.json())
    .then(fetchedPosts => {
      // console.log(json);
      fs.writeFileSync("./result/posts.json", JSON.stringify(fetchedPosts, null, 2))
      //send back some information
      // res.end("welcome to Zuri Intenship!");
      res.writeHead(200)
      res.end("written to the file successfully");
    })
    .catch(err => {
      console.log(err);
      res.writeHead(500);
      res.end("encountered an error")
    })
})

// create a port
server.listen(4000, '127.0.0.1');

console.log("yes, you have created a server");